# ORCHESTRA-OS — USB Deployment Kit

## Quick Start

```bash
bash scripts/sanity_check.sh     # Verify environment
bash scripts/install.sh          # Install kernel + build userspace + bridge
sudo reboot                      # Boot ORCHESTRA kernel
bash scripts/build_bpf.sh        # Compile BPF scheduler
bash scripts/load.sh             # Load scheduler
bash scripts/stress_suite.sh 60  # Run stress tests
bash scripts/benchmark_suite.sh  # Compare CFS vs scx_simple vs ORCHESTRA
bash scripts/unload.sh           # Remove scheduler
```

## Requirements
- Linux 6.12+ with CONFIG_SCHED_CLASS_EXT=y, CONFIG_DEBUG_INFO_BTF=y
- gcc, clang, make, bpftool, libbpf-devel
- Root for kernel operations

## Files
```
├── README.md
├── kernel/   Prebuilt v6.12.96 bzImage + config
├── bpf/      BPF scheduler source + compiled .bpf.o
├── bridge/   Bridge CLI source (compile on target: cc -O2 orchestra_bridge.c -o orchestra_bridge -lbpf)
├── src/      Userspace prototype + tests
└── scripts/
    ├── sanity_check.sh     Check environment
    ├── install.sh          One-command setup
    ├── build_bpf.sh        Compile BPF
    ├── load.sh / unload.sh Attach/detach scheduler
    ├── stress_suite.sh     CPU, memory, I/O, mixed stress
    ├── benchmark_suite.sh  CFS vs scx_simple vs ORCHESTRA
    └── full_compare.sh     Deep comparison with CSV output
```
