#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
KSRC="${ORCHESTRA_KERNEL_SRC:-/usr/src/linux}"
OUT="$HERE/bpf/orchestra_scx_stage7.bpf.o"

echo "=== Build BPF Scheduler ==="
echo "Kernel source: $KSRC"
[ -f /sys/kernel/btf/vmlinux ] || { echo "ERROR: No BTF. Boot sched_ext kernel."; exit 1; }

sudo bpftool btf dump file /sys/kernel/btf/vmlinux format c > "$HERE/bpf/vmlinux.h"
clang -O2 -target bpf -g -nostdinc -D__BPF__ \
  -I "$HERE/bpf" -I "$KSRC/tools/lib" -I "$KSRC/include" -I "$KSRC/include/uapi" \
  -I "$KSRC/arch/x86/include" -I "$KSRC/arch/x86/include/generated" \
  -I "$KSRC/tools/sched_ext/include" -I /usr/include/bpf \
  -Wno-missing-declarations -Wno-visibility -Wno-address-of-packed-member \
  -c "$HERE/bpf/orchestra_scx_stage7.bpf.c" -o "$OUT" \
  && echo "OK: $(ls -lh $OUT | awk '{print $5}')" && sha256sum "$OUT"
