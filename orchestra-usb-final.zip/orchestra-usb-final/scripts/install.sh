#!/bin/bash
set -euo pipefail
echo "=== ORCHESTRA-OS USB Installer ==="
HERE="$(cd "$(dirname "$0")/.." && pwd)"

echo "1. Installing kernel..."
if [ -f "$HERE/kernel/vmlinuz-6.12.96-orchestra" ]; then
    sudo cp "$HERE/kernel/vmlinuz-6.12.96-orchestra" /boot/
    sudo cp "$HERE/kernel/config-6.12.96" /boot/ 2>/dev/null || true
    sudo dracut --force "/boot/initramfs-6.12.96-orchestra.img" 6.12.96 2>/dev/null || true
    sudo grubby --add-kernel=/boot/vmlinuz-6.12.96-orchestra \
      --initrd=/boot/initramfs-6.12.96-orchestra.img \
      --title="ORCHESTRA 6.12.96" --make-default
    echo "Kernel installed. Reboot to use."
else
    echo "No prebuilt kernel. Use your own sched_ext kernel (6.12+)."
fi

echo "2. Building bridge CLI..."
cd "$HERE/bridge"
cc -O2 -Wall -Wextra -I"$HERE/bpf" orchestra_bridge.c -o orchestra_bridge -lbpf && echo "Bridge OK" || echo "Bridge needs libbpf (dnf install libbpf-devel)"

echo "3. Building userspace..."
cd "$HERE/src" && make clean && make && echo "Userspace OK"

echo "=== Install complete ==="
echo "Run: bash $HERE/scripts/sanity_check.sh"
echo "Then: bash $HERE/scripts/build_bpf.sh"
echo "Then: bash $HERE/scripts/load.sh"
