#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
OBJ="$HERE/bpf/orchestra_scx_stage7.bpf.o"
[ -f "$OBJ" ] || { echo "No BPF object. Run: bash build_bpf.sh"; exit 1; }
sudo rm -rf /sys/fs/bpf/* 2>/dev/null
for l in $(sudo bpftool link list 2>&1 | grep struct_ops | awk -F: '{print $1}' | tr -d ' '); do sudo bpftool link detach id $l 2>/dev/null; done
sudo bpftool struct_ops register "$OBJ" /sys/fs/bpf/orch 2>&1 | tail -1
sleep 2
echo "State: $(cat /sys/kernel/sched_ext/state)"
for m in bridge_control_ bridge_directiv bridge_telemetr bridge_task_map; do
    ID=$(sudo bpftool map list 2>&1 | grep -m1 "name $m" | awk '{print $1}' | tr -d ':')
    [ -n "$ID" ] && sudo bpftool map pin id $ID "/sys/fs/bpf/$m" 2>/dev/null
done
echo "Loaded. Bridge CLI ready."
