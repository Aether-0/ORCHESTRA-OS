#!/bin/bash
sudo rm -rf /sys/fs/bpf/* 2>/dev/null
for l in $(sudo bpftool link list 2>&1 | grep struct_ops | awk -F: '{print $1}' | tr -d ' '); do sudo bpftool link detach id $l 2>/dev/null; done
sleep 1; echo "State: $(cat /sys/kernel/sched_ext/state 2>/dev/null || echo disabled)"
